import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { GameSettings, ControlMode, MovementKeys, GodAffinity } from "./types";
import { audio } from "./utils/audio";
import GameCanvas from "./components/GameCanvas";
import OptionsMenu from "./components/OptionsMenu";
import Leaderboard from "./components/Leaderboard";
import { 
  Play, 
  Sliders, 
  Trophy, 
  Gamepad2, 
  Volume2, 
  VolumeX, 
  HelpCircle, 
  Activity, 
  ShieldCheck,
  Zap,
  Globe,
  X,
  Flame,
  Sparkles,
  Shield,
  Swords,
  Crown
} from "lucide-react";

const LOCAL_STORAGE_KEY = "crimson_arcade_settings_config";

const INITIAL_SETTINGS: GameSettings = {
  controlMode: ControlMode.Keyboard,
  movementKeys: MovementKeys.WASD,
  bindings: {
    up: "w",
    down: "s",
    left: "a",
    right: "d",
    action1: " ", // Space bar
    action2: "shift",
  },
  soundEnabled: true,
  volume: 0.5,
  particlesEnabled: true,
  screenShakeEnabled: true,
};

export default function App() {
  const [activeScreen, setActiveScreen] = useState<"menu" | "game" | "settings" | "leaderboard">("menu");
  const [settings, setSettings] = useState<GameSettings>(INITIAL_SETTINGS);
  const [selectedGod, setSelectedGod] = useState<GodAffinity>(GodAffinity.Thor);
  const [showHowToPlay, setShowHowToPlay] = useState(false);
  const [ambientParticles, setAmbientParticles] = useState<{ x: number; y: number; size: number; speed: number; delay: number }[]>([]);

  // Load settings on startup
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSettings(parsed);
        audio.setVolume(parsed.volume);
        audio.setSoundEnabled(parsed.soundEnabled);
      } catch (e) {
        setSettings(INITIAL_SETTINGS);
      }
    } else {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(INITIAL_SETTINGS));
    }

    // Populate ambient floating sparkles for the cosmic divine atmosphere
    const tempParticles = Array.from({ length: 30 }).map(() => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2.5 + 1,
      speed: Math.random() * 18 + 12,
      delay: Math.random() * -20,
    }));
    setAmbientParticles(tempParticles);
  }, []);

  const handlePlayGame = () => {
    audio.playPowerUp();
    setActiveScreen("game");
  };

  const handleOpenSettings = () => {
    audio.playClick();
    setActiveScreen("settings");
  };

  const handleOpenLeaderboard = () => {
    audio.playClick();
    setActiveScreen("leaderboard");
  };

  const handleSaveSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newSettings));
    audio.setVolume(newSettings.volume);
    audio.setSoundEnabled(newSettings.soundEnabled);
    setActiveScreen("menu");
  };

  const handleToggleSoundQuick = () => {
    const nextSound = !settings.soundEnabled;
    const updated = { ...settings, soundEnabled: nextSound };
    setSettings(updated);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
    audio.setSoundEnabled(nextSound);
    audio.playClick();
  };

  // Get God Info helper
  const getGodDetails = (affinity: GodAffinity) => {
    switch (affinity) {
      case GodAffinity.Thor:
        return {
          name: "Thor Odinson",
          title: "Demi God of Thunder",
          desc: "Unleashes high-frequency chain lightning orbs. Exceptional fire rate.",
          color: "border-cyan-500 shadow-[0_0_15px_rgba(34,211,238,0.3)] text-cyan-400 bg-cyan-950/10",
          icon: <Zap size={18} className="text-cyan-400" />
        };
      case GodAffinity.Ares:
        return {
          name: "Ares Phobos",
          title: "Demi God of War",
          desc: "Casts massive destructive plasma fireballs. Immense splash damage.",
          color: "border-red-600 shadow-[0_0_15px_rgba(220,38,38,0.3)] text-red-500 bg-red-950/10",
          icon: <Flame size={18} className="text-red-500" />
        };
      case GodAffinity.Freya:
        return {
          name: "Freya Vanadis",
          title: "Valkyrie of Light",
          desc: "Channels sacred solar energy. Extreme shield speed and double lasers.",
          color: "border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.3)] text-amber-400 bg-amber-950/10",
          icon: <Sparkles size={18} className="text-amber-400" />
        };
      case GodAffinity.Loki:
        return {
          name: "Loki Laufey",
          title: "Deceiver of Shadows",
          desc: "Fires twin volatile dark void orbs. High displacement velocity.",
          color: "border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.3)] text-purple-400 bg-purple-950/10",
          icon: <Shield size={18} className="text-purple-400" />
        };
    }
  };

  return (
    <div className="relative w-screen h-screen bg-[#030308] text-white font-sans overflow-hidden select-none">
      
      {/* Cinematic Scanlines & Vignette Layer */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(10,8,8,0)_50%,rgba(0,0,0,0.35)_50%),linear-gradient(90deg,rgba(255,0,0,0.03),rgba(0,255,0,0.01),rgba(0,0,255,0.03))] bg-[size:100%_4px,6px_100%] pointer-events-none z-10" />
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(180,20,20,0.08)_0%,rgba(0,0,0,0.98)_85%)] pointer-events-none z-0" />
      
      {/* 2.5D Isometric Gridlines Pattern */}
      <div className="absolute inset-0 opacity-[0.04] bg-[linear-gradient(to_right,#ef4444_1px,transparent_1px),linear-gradient(to_bottom,#ef4444_1px,transparent_1px)] bg-[size:60px_60px] pointer-events-none z-0 transform -skew-x-12" />

      {/* Cosmic Divine Sparks */}
      {settings.particlesEnabled && activeScreen !== "game" && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          {ambientParticles.map((pt, i) => {
            const glowColor = i % 2 === 0 ? "bg-red-500" : "bg-cyan-500";
            return (
              <div
                key={i}
                className={`absolute ${glowColor} rounded-full opacity-40 blur-[1px]`}
                style={{
                  left: `${pt.x}%`,
                  top: `${pt.y}%`,
                  width: `${pt.size}px`,
                  height: `${pt.size}px`,
                  animation: `floatUp ${pt.speed}s linear infinite`,
                  animationDelay: `${pt.delay}s`,
                }}
              />
            );
          })}
        </div>
      )}

      {/* Top Right Quick Controls */}
      {activeScreen !== "game" && (
        <div className="absolute top-4 right-4 z-20 flex gap-2">
          <button
            onClick={() => {
              audio.playClick();
              setShowHowToPlay(prev => !prev);
            }}
            className="p-2 md:py-2 md:px-4 rounded border border-zinc-800/80 hover:border-red-600 bg-zinc-950/90 hover:bg-zinc-900 text-zinc-300 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold font-mono tracking-wider shadow-[0_0_10px_rgba(0,0,0,0.5)]"
            title="Aetherial Combat Guide"
          >
            <HelpCircle size={15} /> HOW TO PLAY
          </button>
          
          <button
            onClick={handleToggleSoundQuick}
            className="p-2 rounded border border-zinc-800/80 hover:border-red-600 bg-zinc-950/90 hover:bg-zinc-900 text-zinc-300 hover:text-white transition-all flex items-center justify-center"
            title="Toggle Sound"
          >
            {settings.soundEnabled ? (
              <Volume2 size={16} className="text-red-500 animate-pulse" />
            ) : (
              <VolumeX size={16} className="text-zinc-500" />
            )}
          </button>
        </div>
      )}

      {/* Main Orchestration Layer */}
      <AnimatePresence mode="wait">
        
        {/* 1. MAIN MENU SCREEN (Pure English & High God Theme Features) */}
        {activeScreen === "menu" && (
          <motion.div
            key="menu"
            initial={{ opacity: 0, scale: 0.99 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.01 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="relative w-full h-full flex flex-col items-center justify-center p-4 md:p-6 z-10"
          >
            <div className="w-full max-w-4xl flex flex-col items-center text-center">
              
              {/* Divine Affinity Title */}
              <div className="flex items-center gap-2 px-4 py-1.5 bg-red-950/15 border border-red-900/40 rounded-full mb-6 backdrop-blur-md">
                <Crown size={12} className="text-red-500 animate-pulse" />
                <span className="text-[10px] font-bold tracking-widest text-red-400 uppercase font-mono">
                  DEMI GOD REALM • COVENANT OF RAGNAROK v2.0
                </span>
              </div>

              {/* RAGNAROK BRAND LOGO CONTAINER - Custom 60% Image Alignment */}
              <div className="w-full max-w-lg md:max-w-xl mb-4 relative flex justify-center items-center group">
                <div className="absolute inset-0 bg-red-600/10 blur-[50px] rounded-full pointer-events-none" />
                
                <img
                  src="https://res.cloudinary.com/dsucg33fv/image/upload/v1782709347/logo_i8827v.png"
                  alt="Demi God Ragnarok Logo"
                  referrerPolicy="no-referrer"
                  className="w-[85%] md:w-[65%] h-auto object-contain relative z-10 drop-shadow-[0_0_25px_rgba(239,68,68,0.5)] select-none pointer-events-none animate-float"
                />

                {/* Sweeping Holy Scan Laser Line */}
                <div className="absolute top-1/2 left-[5%] right-[5%] h-[1.5px] bg-red-500 shadow-[0_0_15px_rgba(239,68,68,1)] pointer-events-none z-10 animate-scan" />
              </div>

              {/* STATS & SELECTOR FOR DIVINE CONVENANT (DEMI GODS) */}
              <div className="w-full max-w-3xl mb-8">
                <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-400 mb-3 font-mono flex items-center justify-center gap-1.5">
                  <Swords size={12} className="text-red-500" /> SELECT YOUR DIVINE AFFINITY
                </h4>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[GodAffinity.Thor, GodAffinity.Ares, GodAffinity.Freya, GodAffinity.Loki].map((affinity) => {
                    const info = getGodDetails(affinity);
                    const isSelected = selectedGod === affinity;
                    return (
                      <button
                        key={affinity}
                        onClick={() => {
                          audio.playPowerUp();
                          setSelectedGod(affinity);
                        }}
                        className={`p-3 rounded-md border-2 text-left transition-all duration-300 relative overflow-hidden flex flex-col justify-between ${
                          isSelected 
                            ? `${info.color} scale-[1.03] bg-zinc-950`
                            : "border-zinc-900 bg-zinc-950/40 text-zinc-400 hover:border-zinc-800 hover:bg-zinc-900/30"
                        }`}
                      >
                        {/* Shimmer overlay for selected */}
                        {isSelected && (
                          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />
                        )}
                        
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-black uppercase font-mono tracking-wider opacity-60">
                            {affinity.split("_")[1]}
                          </span>
                          {info.icon}
                        </div>

                        <div>
                          <h5 className="text-xs font-bold text-white font-mono leading-none mb-1">
                            {info.name}
                          </h5>
                          <span className="text-[9px] block text-zinc-500 font-mono mb-1">
                            {info.title}
                          </span>
                          <p className="text-[9.5px] text-zinc-400 font-sans leading-tight line-clamp-2">
                            {info.desc}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* ACTION MENU INTERACTION */}
              <div id="main-menu-buttons" className="w-full max-w-sm space-y-3 px-4 relative z-20">
                
                <button
                  id="play-game-button"
                  onClick={handlePlayGame}
                  className="w-full py-4 px-6 rounded bg-red-600 hover:bg-red-500 text-white font-black text-sm uppercase tracking-[0.25em] transition-all duration-300 border border-red-500 shadow-[0_0_20px_rgba(220,38,38,0.4)] hover:shadow-[0_0_35px_rgba(220,38,38,0.7)] hover:-translate-y-0.5 active:scale-[0.98] flex items-center justify-center gap-2 group/btn"
                >
                  <Play size={16} className="text-white fill-white group-hover/btn:scale-115 transition-transform" />
                  <span>ENTER ARENA</span>
                </button>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    id="options-button"
                    onClick={handleOpenSettings}
                    className="py-3 px-4 rounded bg-zinc-950 hover:bg-zinc-900 text-white font-bold text-xs uppercase tracking-wider transition-all duration-300 border border-red-600/60 hover:border-red-500 shadow-[0_0_12px_rgba(220,38,38,0.1)] flex items-center justify-center gap-1.5"
                  >
                    <Sliders size={13} className="text-red-500" />
                    <span>CONTROLS</span>
                  </button>

                  <button
                    id="leaderboard-button"
                    onClick={handleOpenLeaderboard}
                    className="py-3 px-4 rounded bg-zinc-950 hover:bg-zinc-900 text-white font-bold text-xs uppercase tracking-wider transition-all duration-300 border border-zinc-800 hover:border-red-500 shadow-md flex items-center justify-center gap-1.5"
                  >
                    <Trophy size={13} className="text-yellow-500" />
                    <span>VALHALLA</span>
                  </button>
                </div>

              </div>

              {/* QUICK STATUS HUD FOOTER */}
              <div className="mt-8 flex justify-center gap-6 text-[10px] uppercase font-mono tracking-wider text-zinc-500 bg-zinc-950/40 px-6 py-2.5 rounded-full border border-zinc-900/40 backdrop-blur-sm">
                <span className="flex items-center gap-1.5">
                  <Activity size={10} className="text-red-500" /> CONTROL MODE:{" "}
                  <strong className="text-white">
                    {settings.controlMode === ControlMode.Touch ? "VIRTUAL TOUCH" : `KEYBOARD (${settings.movementKeys})`}
                  </strong>
                </span>
                <span className="text-zinc-800">|</span>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck size={10} className="text-red-500" /> DIVINE AFFINITY:{" "}
                  <strong className="text-red-400 uppercase">
                    {selectedGod.split("_")[0]}
                  </strong>
                </span>
              </div>

            </div>

            {/* HOW TO PLAY HELP MODAL DRAWER */}
            {showHowToPlay && (
              <div className="absolute inset-0 bg-black/95 z-40 flex items-center justify-center p-4 backdrop-blur-md">
                <div className="bg-zinc-950 border border-red-600 max-w-md w-full rounded p-6 relative shadow-2xl">
                  <button 
                    onClick={() => {
                      audio.playClick();
                      setShowHowToPlay(false);
                    }}
                    className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors"
                  >
                    <X size={18} />
                  </button>
                  
                  <h3 className="text-sm font-black text-red-500 uppercase tracking-widest mb-4 flex items-center gap-1.5 font-mono">
                    <Gamepad2 size={18} /> AETHERIAL ARCADE COMBAT PROTOCOL
                  </h3>

                  <div className="space-y-4 text-xs text-zinc-300 leading-relaxed font-mono">
                    <div className="border-l-2 border-red-600 pl-2.5">
                      <strong className="text-white block uppercase tracking-wider mb-0.5">Aetherial Movement</strong>
                      {settings.controlMode === ControlMode.Touch 
                        ? "Utilize the fluid simulated screen joystick on the bottom-left to float across the field." 
                        : `Use the default standard [ ${settings.movementKeys} ] keys on your keyboard to navigate the Demi God.`}
                    </div>

                    <div className="border-l-2 border-red-600 pl-2.5">
                      <strong className="text-white block uppercase tracking-wider mb-0.5">Divine Magic (Action 1)</strong>
                      {settings.controlMode === ControlMode.Touch 
                        ? "Hold the primary 'FIRE' orb on the bottom-right to automatically unleash elemental magic." 
                        : `Hold down the [ ${settings.bindings.action1 === " " ? "SPACE" : settings.bindings.action1.toUpperCase()} ] key on your keyboard.`}
                    </div>

                    <div className="border-l-2 border-red-600 pl-2.5">
                      <strong className="text-white block uppercase tracking-wider mb-0.5">Aegis Ward Shield (Action 2)</strong>
                      {settings.controlMode === ControlMode.Touch 
                        ? "Tap the cyan 'SHIELD' button to activate complete invincibility and knock back hostiles." 
                        : `Tap [ ${settings.bindings.action2.toUpperCase()} ] to manifest the Aegis divine shield (has a brief cooldown).`}
                    </div>

                    <div className="border border-red-950/60 bg-red-950/15 p-3 rounded text-zinc-400">
                      <span className="text-yellow-500 font-bold flex items-center gap-1.5 mb-1">
                        <Zap size={11} className="shrink-0" /> MULTIPLIER COMBOS
                      </span>
                      Destroying aggressive Jotunn orbs splits them into frantic minor spirits. Exterminate fiends rapidly to escalate score multipliers!
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      audio.playClick();
                      setShowHowToPlay(false);
                    }}
                    className="w-full mt-6 py-3 rounded bg-red-600 hover:bg-red-500 text-white font-bold tracking-widest text-xs uppercase transition-all shadow-[0_0_12px_rgba(220,38,38,0.3)]"
                  >
                    CONFIRM DIVINE DECREE
                  </button>
                </div>
              </div>
            )}

          </motion.div>
        )}

        {/* 2. PLAYABLE CANVAS GAME VIEW */}
        {activeScreen === "game" && (
          <motion.div
            key="game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 w-full h-full z-10"
          >
            <GameCanvas
              settings={settings}
              selectedGod={selectedGod}
              onBackToMenu={() => setActiveScreen("menu")}
              onOpenSettings={() => setActiveScreen("settings")}
            />
          </motion.div>
        )}

        {/* 3. SETTINGS & OPTIONS WINDOW */}
        {activeScreen === "settings" && (
          <motion.div
            key="settings"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="absolute inset-0 w-full h-full z-10"
          >
            <OptionsMenu
              settings={settings}
              onSave={handleSaveSettings}
              onBack={() => setActiveScreen("menu")}
            />
          </motion.div>
        )}

        {/* 4. LEADERBOARD SCOREBOARD WINDOW */}
        {activeScreen === "leaderboard" && (
          <motion.div
            key="leaderboard"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="absolute inset-0 w-full h-full z-10"
          >
            <Leaderboard
              onBack={() => setActiveScreen("menu")}
            />
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
