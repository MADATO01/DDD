import React, { useRef, useEffect, useState, useMemo } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Billboard, Html } from "@react-three/drei";
import { GameSettings, ControlMode, KeyBindings, ScoreRecord, MovementKeys, GodAffinity } from "../types";
import { audio } from "../utils/audio";
import {
  Play, Pause, Volume2, VolumeX, Award, RotateCcw, X, Shield, Sparkles, Zap,
  Flame, Swords, Skull, Activity, Heart
} from "lucide-react";

interface GameCanvasProps {
  settings: GameSettings;
  selectedGod?: GodAffinity;
  onBackToMenu: () => void;
  onOpenSettings: () => void;
}

// ─── Entity interfaces ───────────────────────────────────────────────────────

interface Enemy {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  hp: number;
  maxHp: number;
  speed: number;
  size: number;
  type: "normal" | "boss";
  hitCount: number;          // 0 = untouched, 1 = first hit, 2 = dying
  knockbackVel: THREE.Vector3;
  flashTimer: number;        // red flash timer (damage taken)
  whiteFlashTimer: number;   // white flash for death anim
  dyingTimer: number;        // counts down during death animation
  isDying: boolean;
  frameRow: number;          // 0=stand, 1=walk
  animFrame: number;
  frameTimer: number;
  facingLeft: boolean;
  isBoss: boolean;
  shootTimer: number;        // boss projectile cooldown
}

interface Item {
  id: string;
  position: THREE.Vector3;
  bobTimer: number;
}

interface Projectile {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  size: number;
  damage: number;
  color: string;
}

interface Particle {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  color: string;
  size: number;
  life: number;
  maxLife: number;
}

interface FloatingTextItem {
  id: string;
  text: string;
  color: string;
  position: [number, number, number];
}

interface SlashVisual {
  active: boolean;
  position: [number, number, number];
  angle: number;
  opacity: number;
  color: string;
}

interface BlastVisual {
  active: boolean;
  position: [number, number, number];
  radius: number;
  opacity: number;
  color: string;
}

// ─── Main exported component ──────────────────────────────────────────────────

export default function GameCanvas({
  settings,
  selectedGod = GodAffinity.Thor,
  onBackToMenu,
  onOpenSettings,
}: GameCanvasProps) {

  // ── State ──
  const [score, setScore] = useState(0);
  const [wave, setWave] = useState(1);
  const [kills, setKills] = useState(0);
  const [playerHearts, setPlayerHearts] = useState(5);   // 5 lives (hearts)
  const [shieldCharge, setShieldCharge] = useState(100);
  const [playerName, setPlayerName] = useState("");
  const [highScoreSaved, setHighScoreSaved] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [soundOn, setSoundOn] = useState(settings.soundEnabled);

  const keysPressed = useRef<{ [key: string]: boolean }>({});

  // Touch state
  const [isJoyActive, setIsJoyActive] = useState(false);
  const joystickDir = useRef(new THREE.Vector2(0, 0));
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);
  const touchCurrentPos = useRef<{ x: number; y: number } | null>(null);
  const touchShootActive = useRef(false);

  // Audio sync
  useEffect(() => {
    audio.setVolume(settings.volume);
    audio.setSoundEnabled(soundOn);
    if (isPlaying && soundOn && !isPaused && !isGameOver) audio.startBGM();
    else audio.stopBGM();
  }, [soundOn, isPlaying, isPaused, isGameOver]);

  // Key listeners
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      keysPressed.current[k] = true;
      if (k === "escape") { e.preventDefault(); handlePauseToggle(); }
    };
    const up = (e: KeyboardEvent) => { keysPressed.current[e.key.toLowerCase()] = false; };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, [isPlaying, isPaused, isGameOver]);

  const handlePauseToggle = () => {
    if (isGameOver || !isPlaying) return;
    audio.playClick();
    setIsPaused(p => !p);
  };

  const handleSoundToggle = () => {
    const n = !soundOn;
    setSoundOn(n);
    audio.setSoundEnabled(n);
    audio.playClick();
  };

  const resetGame = () => {
    audio.playPowerUp();
    setScore(0); setWave(1); setKills(0); setPlayerHearts(5);
    setShieldCharge(100); setPlayerName(""); setHighScoreSaved(false);
    setIsGameOver(false); setIsPaused(false); setIsPlaying(true);
    keysPressed.current = {};
  };

  const handleSaveHighScore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) return;
    const record: ScoreRecord = {
      id: Date.now().toString(),
      name: playerName.toUpperCase().substring(0, 12),
      score, date: new Date().toISOString().split("T")[0], wave,
    };
    const saved = localStorage.getItem("crimson_arcade_high_scores");
    let records: ScoreRecord[] = [];
    if (saved) try { records = JSON.parse(saved); } catch (_) {}
    records.push(record);
    records.sort((a, b) => b.score - a.score);
    records = records.slice(0, 10);
    localStorage.setItem("crimson_arcade_high_scores", JSON.stringify(records));
    setHighScoreSaved(true);
    audio.playPowerUp();
  };

  // Touch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (settings.controlMode !== ControlMode.Touch) return;
    const touch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    const touchX = touch.clientX - rect.left;
    const touchY = touch.clientY - rect.top;
    if (touchX < rect.width / 2) {
      setIsJoyActive(true);
      touchStartPos.current = { x: touchX, y: touchY };
      touchCurrentPos.current = { x: touchX, y: touchY };
      joystickDir.current.set(0, 0);
    }
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    if (settings.controlMode !== ControlMode.Touch || !isJoyActive || !touchStartPos.current) return;
    const touch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    const touchX = touch.clientX - rect.left;
    const touchY = touch.clientY - rect.top;
    touchCurrentPos.current = { x: touchX, y: touchY };
    const dx = touchX - touchStartPos.current.x;
    const dy = touchY - touchStartPos.current.y;
    const dist = Math.hypot(dx, dy);
    if (dist === 0) joystickDir.current.set(0, 0);
    else {
      const angle = Math.atan2(dy, dx);
      const intensity = Math.min(1, dist / 50);
      joystickDir.current.set(Math.cos(angle) * intensity, Math.sin(angle) * intensity);
    }
  };
  const handleTouchEnd = () => {
    setIsJoyActive(false);
    touchStartPos.current = null; touchCurrentPos.current = null;
    joystickDir.current.set(0, 0);
  };

  const godProperties = useMemo(() => {
    switch (selectedGod) {
      case GodAffinity.Thor:   return { glow: "#22d3ee", slashColor: "#38bdf8", blastColor: "#06b6d4", speed: 6.8, baseDamage: 25 };
      case GodAffinity.Ares:   return { glow: "#ef4444", slashColor: "#f87171", blastColor: "#dc2626", speed: 5.4, baseDamage: 40 };
      case GodAffinity.Freya:  return { glow: "#fbbf24", slashColor: "#fef08a", blastColor: "#f59e0b", speed: 7.8, baseDamage: 28 };
      case GodAffinity.Loki:   return { glow: "#a855f7", slashColor: "#e9d5ff", blastColor: "#8b5cf6", speed: 7.2, baseDamage: 32 };
    }
  }, [selectedGod]);

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div
      className="w-full h-screen relative bg-[#020205] overflow-hidden flex flex-col justify-between select-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <style>{`
        @keyframes floatUpFade {
          0%   { transform: translateY(0);     opacity: 1; }
          100% { transform: translateY(-55px); opacity: 0; }
        }
        .animate-float-fade { animation: floatUpFade 0.9s cubic-bezier(0.16,1,0.3,1) forwards; }
        @keyframes heartbeat { 0%,100%{transform:scale(1)} 50%{transform:scale(1.18)} }
        .heart-pulse { animation: heartbeat 0.6s ease-in-out infinite; }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
      `}</style>

      {/* ── 3D Canvas ── */}
      {isPlaying && !isPaused && !isGameOver && (
        <div className="absolute inset-0 w-full h-full z-0">
          <Canvas shadows gl={{ antialias: true }}>
            <color attach="background" args={["#030208"]} />
            <fog attach="fog" args={["#030208", 14, 36]} />
            <GameScene
              settings={settings}
              selectedGod={selectedGod}
              godProps={godProperties}
              keysPressed={keysPressed}
              joystickDir={joystickDir}
              touchShootActive={touchShootActive}
              isPaused={isPaused}
              isPlaying={isPlaying}
              isGameOver={isGameOver}
              setPlayerHearts={setPlayerHearts}
              setScore={setScore}
              setWave={setWave}
              setKills={setKills}
              setShieldCharge={setShieldCharge}
              setIsGameOver={setIsGameOver}
              setIsPlaying={setIsPlaying}
              wave={wave}
              score={score}
              playerHearts={playerHearts}
            />
          </Canvas>
        </div>
      )}

      {/* ── HUD ── */}
      {isPlaying && !isGameOver && (
        <div className="absolute top-0 left-0 w-full p-3 flex justify-between items-start z-10 pointer-events-none">
          {/* Left: Hearts + Blast */}
          <div className="flex flex-col gap-2 bg-black/75 p-3 rounded-lg border border-amber-900/50 backdrop-blur-md pointer-events-auto">
            {/* Hearts row */}
            <div className="flex flex-col">
              <span className="text-[9px] uppercase tracking-widest text-amber-700 font-bold font-mono mb-1.5 flex items-center gap-1">
                <Heart size={9} className="text-red-500" /> DIVINE LIFE
              </span>
              <div className="flex gap-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className={`transition-all duration-200 ${i < playerHearts ? "text-red-500" : "text-zinc-800"} ${i === playerHearts - 1 && playerHearts <= 2 ? "heart-pulse" : ""}`}>
                    <Heart size={22} fill={i < playerHearts ? "#ef4444" : "transparent"} stroke={i < playerHearts ? "#ef4444" : "#27272a"} strokeWidth={1.5} />
                  </div>
                ))}
              </div>
            </div>
            {/* Blast charge */}
            <div className="flex flex-col">
              <div className="flex justify-between items-center text-[9px] uppercase font-bold tracking-wider mb-1">
                <span className="text-zinc-500 flex items-center gap-1"><Shield size={9} className="text-cyan-400" /> Blast Energy</span>
                <span className="text-cyan-400 font-mono">{shieldCharge}%</span>
              </div>
              <div className="w-44 h-2 bg-zinc-950 rounded border border-zinc-800 overflow-hidden">
                <div className={`h-full transition-all duration-200 rounded ${shieldCharge === 100 ? "bg-cyan-400 shadow-[0_0_6px_#22d3ee]" : "bg-cyan-700"}`} style={{ width: `${shieldCharge}%` }} />
              </div>
            </div>
          </div>

          {/* Center: Score */}
          <div className="flex flex-col items-center bg-black/80 px-5 py-2 rounded-lg border border-amber-800/30 backdrop-blur-md">
            <span className="text-[9px] uppercase tracking-widest text-amber-700 font-bold font-mono">VALHALLA SCORE</span>
            <span className="text-2xl font-black font-mono tracking-wider text-white">{score.toLocaleString()}</span>
            {wave > 1 && (
              <div className="mt-1 flex items-center gap-1 bg-red-950/40 border border-red-900/40 px-2 py-0.5 rounded">
                <Zap size={9} className="text-yellow-400" />
                <span className="text-[9px] font-bold font-mono text-amber-400">WAVE ×{1 + Math.floor(wave / 2)}</span>
              </div>
            )}
          </div>

          {/* Right: Wave + buttons */}
          <div className="flex gap-2 items-center pointer-events-auto">
            <div className="bg-black/75 px-4 py-2 rounded-lg border border-zinc-800 backdrop-blur-md text-right flex flex-col">
              <span className="text-[8px] uppercase tracking-widest text-zinc-500 font-bold">Ragnarok Wave</span>
              <span className="text-sm font-mono font-bold text-red-400">{wave}</span>
            </div>
            <button onClick={handlePauseToggle} className="p-2.5 rounded-lg border border-zinc-800 hover:border-amber-600 bg-zinc-950/90 text-white transition-all cursor-pointer" title="Pause (ESC)">
              <Pause size={15} />
            </button>
            <button onClick={handleSoundToggle} className="p-2.5 rounded-lg border border-zinc-800 hover:border-amber-600 bg-zinc-950/90 text-white transition-all cursor-pointer">
              {soundOn ? <Volume2 size={15} className="text-amber-500" /> : <VolumeX size={15} className="text-zinc-500" />}
            </button>
          </div>
        </div>
      )}

      {/* ── Touch controls ── */}
      {isPlaying && !isPaused && !isGameOver && settings.controlMode === ControlMode.Touch && (
        <div className="absolute inset-x-0 bottom-0 p-8 flex justify-between items-end z-20 pointer-events-none">
          <div className="w-32 h-32 rounded-full border border-amber-800/50 bg-black/40 relative pointer-events-auto flex items-center justify-center" style={{ touchAction: "none" }}>
            {isJoyActive && touchStartPos.current && touchCurrentPos.current && (
              <div className="w-12 h-12 rounded-full bg-amber-600/85 border border-white/40 shadow-[0_0_12px_rgba(217,119,6,0.6)] absolute pointer-events-none"
                style={{ left: `calc(50% - 24px + ${Math.min(40, touchCurrentPos.current.x - touchStartPos.current.x)}px)`, top: `calc(50% - 24px + ${Math.min(40, touchCurrentPos.current.y - touchStartPos.current.y)}px)` }} />
            )}
            {!isJoyActive && <div className="w-10 h-10 rounded-full bg-zinc-800/40 border border-zinc-700/80 absolute pointer-events-none" />}
          </div>
          <div className="flex gap-4 items-end pointer-events-auto">
            <button onTouchStart={(e) => { e.preventDefault(); keysPressed.current["o"] = true; }} onTouchEnd={() => { keysPressed.current["o"] = false; }}
              className={`w-14 h-14 rounded-full flex flex-col items-center justify-center border transition-all ${shieldCharge < 100 ? "border-zinc-800 bg-zinc-950/70 text-zinc-600" : "border-cyan-500 bg-cyan-950/30 text-cyan-400 active:scale-95 shadow-[0_0_12px_rgba(34,211,238,0.3)] cursor-pointer"}`}>
              <Shield size={18} /><span className="text-[7px] font-extrabold mt-0.5 uppercase font-mono">BLAST</span>
            </button>
            <button onTouchStart={(e) => { e.preventDefault(); keysPressed.current["p"] = true; }} onTouchEnd={() => { keysPressed.current["p"] = false; }}
              className="w-20 h-20 rounded-full flex flex-col items-center justify-center border-2 border-red-600 bg-red-950/35 text-white active:scale-90 shadow-[0_0_18px_rgba(220,38,38,0.45)] cursor-pointer">
              <Sparkles size={24} className="text-red-400" /><span className="text-[9px] font-black tracking-widest mt-1 uppercase font-mono">PUNCH</span>
            </button>
          </div>
        </div>
      )}

      {/* ── Start Screen ── */}
      {!isPlaying && !isGameOver && (
        <div className="absolute inset-0 bg-black/95 z-20 flex flex-col items-center justify-center p-6 text-center">
          <div className="max-w-md w-full bg-zinc-950 border border-amber-900/40 rounded-xl p-6 shadow-2xl flex flex-col items-center relative">
            <div className="absolute inset-0 rounded-xl bg-gradient-to-b from-amber-900/5 to-transparent pointer-events-none" />
            <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-2 font-mono">RAGNAROK CHRONICLES</span>
            <h3 className="text-lg font-black text-white uppercase tracking-widest mb-3 font-mono flex items-center gap-2">
              <Swords size={18} className="text-amber-500 animate-pulse" /> SURVIVAL ARENA
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed mb-5 font-sans">
              Survive endless waves of enemies. Collect potions to restore hearts. Defeat the Boss to advance!
            </p>
            <div className="w-full mb-5 bg-black/50 p-4 border border-zinc-900 rounded-lg text-xs font-mono">
              <div className="flex gap-3 text-zinc-400 mb-2">
                <Heart size={14} className="text-red-500 shrink-0 mt-0.5" />
                <span><strong className="text-white">5 Hearts</strong> — take damage to lose them</span>
              </div>
              <div className="flex gap-3 text-zinc-400 mb-2">
                <span className="text-amber-500 shrink-0 text-base leading-none">⚗</span>
                <span><strong className="text-white">Potions</strong> drop on map — walk over to heal</span>
              </div>
              <div className="flex gap-3 text-zinc-400">
                <Skull size={14} className="text-purple-400 shrink-0 mt-0.5" />
                <span>Hit enemies <strong className="text-white">twice</strong> to destroy them</span>
              </div>
            </div>
            <button onClick={resetGame} className="w-full py-3 rounded-lg bg-gradient-to-r from-amber-700 to-red-700 hover:from-amber-600 hover:to-red-600 text-white font-bold tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(180,83,9,0.4)] flex items-center justify-center gap-2 text-sm font-mono cursor-pointer">
              <Play size={16} /> ENTER THE ARENA
            </button>
          </div>
        </div>
      )}

      {/* ── Pause ── */}
      {isPaused && (
        <div className="absolute inset-0 bg-black/85 z-30 flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-zinc-950 border-2 border-amber-700 rounded-xl p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white uppercase tracking-widest mb-6 flex items-center justify-center gap-2 font-mono">
              <Pause className="text-amber-500 animate-pulse" size={20} /> PAUSED
            </h3>
            <div className="space-y-3 font-mono">
              <button onClick={handlePauseToggle} className="w-full py-2.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-amber-600 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer">Resume</button>
              <button onClick={resetGame} className="w-full py-2.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-amber-600 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer">Restart</button>
              <div className="border-t border-zinc-900 pt-3">
                <button onClick={() => { audio.playClick(); audio.stopBGM(); onBackToMenu(); }} className="w-full py-2.5 rounded-lg bg-red-950/20 border border-red-900/40 hover:bg-red-950/40 text-red-400 font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer">
                  <X size={13} /> Back to Menu
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Game Over ── */}
      {isGameOver && (
        <div className="absolute inset-0 bg-black/95 z-40 flex items-center justify-center p-6 text-center">
          <div className="w-full max-w-md bg-zinc-950 border-2 border-red-700 rounded-xl p-6 shadow-[0_0_50px_rgba(220,38,38,0.35)]">
            <span className="text-[10px] font-bold text-red-500 uppercase tracking-widest bg-red-950/30 px-3 py-1.5 rounded-lg border border-red-900/40 inline-block mb-4 font-mono">
              DIVINE VESSEL SHATTERED
            </span>
            <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-red-300 to-red-600 tracking-widest uppercase mb-6 animate-pulse font-mono">DEFEAT</h2>
            <div className="grid grid-cols-3 gap-2 text-zinc-400 text-xs mb-6 font-mono">
              <div className="bg-black/50 p-2.5 border border-zinc-900 rounded-lg">
                <span className="text-[9px] uppercase text-zinc-500 font-bold block mb-1">SCORE</span>
                <span className="text-base font-bold text-white">{score.toLocaleString()}</span>
              </div>
              <div className="bg-black/50 p-2.5 border border-zinc-900 rounded-lg">
                <span className="text-[9px] uppercase text-zinc-500 font-bold block mb-1">WAVE</span>
                <span className="text-base font-bold text-red-400">{wave}</span>
              </div>
              <div className="bg-black/50 p-2.5 border border-zinc-900 rounded-lg">
                <span className="text-[9px] uppercase text-zinc-500 font-bold block mb-1">KILLS</span>
                <span className="text-base font-bold text-cyan-400">{kills}</span>
              </div>
            </div>
            {!highScoreSaved ? (
              <form onSubmit={handleSaveHighScore} className="mb-6 bg-amber-950/10 border border-amber-950/40 p-4 rounded-lg font-mono">
                <span className="text-xs text-zinc-300 font-semibold block mb-2">SAVE YOUR NAME TO VALHALLA</span>
                <div className="flex gap-2">
                  <input type="text" required maxLength={10} placeholder="Your warrior name" value={playerName} onChange={(e) => setPlayerName(e.target.value)}
                    className="flex-grow bg-black border border-zinc-800 text-white placeholder-zinc-600 rounded-lg px-3 py-2 text-xs focus:border-amber-600 focus:outline-none uppercase font-mono" />
                  <button type="submit" className="bg-amber-700 hover:bg-amber-600 text-white font-bold text-xs uppercase px-4 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer">
                    <Award size={13} /> Save
                  </button>
                </div>
              </form>
            ) : (
              <div className="mb-6 bg-zinc-900 border border-zinc-800 text-amber-500 p-3 rounded-lg text-xs font-bold tracking-wider flex items-center justify-center gap-1.5 font-mono">
                <Award size={13} /> Recorded in Valhalla!
              </div>
            )}
            <div className="flex gap-3 font-mono">
              <button onClick={resetGame} className="flex-1 py-3 rounded-lg border border-amber-700 bg-amber-950/10 hover:bg-amber-950/30 text-white font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-1 cursor-pointer">
                <RotateCcw size={13} /> Try Again
              </button>
              <button onClick={() => { audio.playClick(); audio.stopBGM(); onBackToMenu(); }} className="flex-1 py-3 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-300 font-bold text-xs uppercase tracking-widest transition-all cursor-pointer">
                Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── GameScene ────────────────────────────────────────────────────────────────

function GameScene({
  settings, selectedGod, godProps, keysPressed, joystickDir, touchShootActive,
  isPaused, isPlaying, isGameOver,
  setPlayerHearts, setScore, setWave, setKills, setShieldCharge,
  setIsGameOver, setIsPlaying,
  wave, score, playerHearts,
}: {
  settings: GameSettings; selectedGod: GodAffinity; godProps: any;
  keysPressed: React.MutableRefObject<{ [key: string]: boolean }>;
  joystickDir: React.MutableRefObject<THREE.Vector2>;
  touchShootActive: React.MutableRefObject<boolean>;
  isPaused: boolean; isPlaying: boolean; isGameOver: boolean;
  setPlayerHearts: React.Dispatch<React.SetStateAction<number>>;
  setScore: React.Dispatch<React.SetStateAction<number>>;
  setWave: React.Dispatch<React.SetStateAction<number>>;
  setKills: React.Dispatch<React.SetStateAction<number>>;
  setShieldCharge: React.Dispatch<React.SetStateAction<number>>;
  setIsGameOver: React.Dispatch<React.SetStateAction<boolean>>;
  setIsPlaying: React.Dispatch<React.SetStateAction<boolean>>;
  wave: number; score: number; playerHearts: number;
}) {
  const { camera } = useThree();
  const [floatingTexts, setFloatingTexts] = useState<FloatingTextItem[]>([]);

  const addFloatingText = (text: string, color: string, pos: THREE.Vector3) => {
    const id = Math.random().toString();
    setFloatingTexts(p => [...p, { id, text, color, position: [pos.x, pos.y + 1.5, pos.z] }]);
    setTimeout(() => setFloatingTexts(p => p.filter(x => x.id !== id)), 900);
  };

  // ── Textures ──
  const groundTexture = useMemo(() => {
    const t = new THREE.TextureLoader().load("https://res.cloudinary.com/dsucg33fv/image/upload/v1782439980/ground_d1kjrx.png");
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(8, 8);  // tighter tiling for 50x50 plane
    return t;
  }, []);

  // Enemy sprite: 256×256 × 4 frames wide × 2 rows (row0=stand, row1=walk)
  const enemyTexture = useMemo(() => {
    const t = new THREE.TextureLoader().load("https://res.cloudinary.com/dsucg33fv/image/upload/v1782709477/enemy_jykcgz.png");
    t.minFilter = THREE.NearestFilter;
    t.magFilter = THREE.NearestFilter;
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    t.repeat.set(0.25, 0.5);
    return t;
  }, []);

  // Boss sprite (single large sprite)
  const bossTexture = useMemo(() => {
    const t = new THREE.TextureLoader().load("https://res.cloudinary.com/dsucg33fv/image/upload/v1782709455/boss_e8jti1.png");
    t.minFilter = THREE.NearestFilter;
    t.magFilter = THREE.NearestFilter;
    return t;
  }, []);

  // Item / potion sprite
  const itemTexture = useMemo(() => {
    const t = new THREE.TextureLoader().load("https://res.cloudinary.com/dsucg33fv/image/upload/v1782709447/potion_ladf9n.png");
    t.minFilter = THREE.NearestFilter;
    t.magFilter = THREE.NearestFilter;
    return t;
  }, []);

  // Player texture (4×4 sheet)
  const playerTexture = useMemo(() => {
    const t = new THREE.TextureLoader().load("https://res.cloudinary.com/dsucg33fv/image/upload/v1782709479/player_umd922.png");
    t.minFilter = THREE.NearestFilter;
    t.magFilter = THREE.NearestFilter;
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    t.repeat.set(0.25, 0.25);
    return t;
  }, []);

  // ── Enemy cloned textures pool ── (we share & offset per enemy individually via material)
  // We'll store per-enemy texture state inside the enemy objects, and render with individual materials.

  // ── Player ──
  const playerMeshRef = useRef<THREE.Mesh>(null);
  const playerPos = useRef(new THREE.Vector3(0, 0, 0));
  const playerVel = useRef(new THREE.Vector3(0, 0, 0));
  const playerFacing = useRef(new THREE.Vector3(0, 0, 1));
  const frameTimer = useRef(0);
  const animFrame = useRef(0);
  const playerState = useRef<"idle" | "walk" | "attack" | "dance">("idle");
  const isFacingLeft = useRef(false);
  const attackTimer = useRef(0);
  const danceTimer = useRef(0);
  const playerInvincible = useRef(0); // invincibility frames after being hit

  const [slashVisual, setSlashVisual] = useState<SlashVisual>({ active: false, position: [0,0,0], angle: 0, opacity: 0, color: godProps.slashColor });
  const [blastVisual, setBlastVisual] = useState<BlastVisual>({ active: false, position: [0,0,0], radius: 0, opacity: 0, color: godProps.blastColor });

  // ── Entities ──
  const enemies = useRef<Enemy[]>([]);
  const projectiles = useRef<Projectile[]>([]);
  const particles = useRef<Particle[]>([]);
  const items = useRef<Item[]>([]);

  // Wave management
  const enemiesRemainingInWave = useRef(0);
  const enemiesSpawnedThisWave = useRef(0);
  const totalEnemiesToSpawn = useRef(0);
  const spawnCooldown = useRef(0);
  const nextWaveDelayTimer = useRef(0);
  const localShieldCharge = useRef(100);
  const bossSpawned = useRef(false);

  // Item spawn timer
  const itemSpawnTimer = useRef(5.0); // spawn first item after 5s

  // Render tick counters for entities (stored per-enemy inside the object)
  const [renderTick, setRenderTick] = useState(0);

  useEffect(() => {
    totalEnemiesToSpawn.current = 6 + wave * 3;
    enemiesSpawnedThisWave.current = 0;
    enemiesRemainingInWave.current = totalEnemiesToSpawn.current;
    spawnCooldown.current = 1.0;
    nextWaveDelayTimer.current = 0;
    bossSpawned.current = false;
  }, [wave]);

  useEffect(() => {
    playerPos.current.set(0, 0, 0);
    playerVel.current.set(0, 0, 0);
    enemies.current = [];
    projectiles.current = [];
    particles.current = [];
    items.current = [];
    localShieldCharge.current = 100;
    setShieldCharge(100);
  }, [isPlaying]);

  const spawnParticles = (pos: THREE.Vector3, color: string, count = 8, sizeFactor = 1.0) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 2;
      particles.current.push({
        id: Math.random().toString(),
        position: pos.clone().add(new THREE.Vector3(0, Math.random() * 0.3, 0)),
        velocity: new THREE.Vector3(Math.cos(angle) * speed, Math.random() * 3 + 1, Math.sin(angle) * speed),
        color, size: (Math.random() * 0.14 + 0.07) * sizeFactor,
        life: 0.55, maxLife: 0.55,
      });
    }
  };

  const spawnItem = (pos: THREE.Vector3) => {
    // random position offset from drop position (or random map spawn)
    items.current.push({
      id: Math.random().toString(),
      position: pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 2, 0, (Math.random() - 0.5) * 2)),
      bobTimer: 0,
    });
  };

  // Spawn items at random map positions every ~10s
  const spawnRandomItem = () => {
    const x = (Math.random() - 0.5) * 42;
    const z = (Math.random() - 0.5) * 42;
    items.current.push({ id: Math.random().toString(), position: new THREE.Vector3(x, 0, z), bobTimer: Math.random() * Math.PI * 2 });
  };

  // ── Main frame loop ──
  useFrame((state, delta) => {
    if (isPaused || isGameOver || !isPlaying) return;
    const dt = Math.min(delta, 0.1);

    // ── Item spawn timer ──
    itemSpawnTimer.current -= dt;
    if (itemSpawnTimer.current <= 0) {
      spawnRandomItem();
      itemSpawnTimer.current = 8.0 + Math.random() * 4.0;
    }

    // ── Item bob animation ──
    for (const item of items.current) {
      item.bobTimer += dt * 2.5;
      item.position.y = 0.5 + Math.sin(item.bobTimer) * 0.18;
    }

    // ── INPUT ──
    let moveX = 0, moveZ = 0;
    const { up, down, left, right, action1, action2 } = settings.bindings;
    if (settings.controlMode === ControlMode.Keyboard) {
      if (keysPressed.current["w"] || keysPressed.current["arrowup"]    || keysPressed.current[up.toLowerCase()])    moveZ -= 1;
      if (keysPressed.current["s"] || keysPressed.current["arrowdown"]  || keysPressed.current[down.toLowerCase()])  moveZ += 1;
      if (keysPressed.current["a"] || keysPressed.current["arrowleft"]  || keysPressed.current[left.toLowerCase()])  moveX -= 1;
      if (keysPressed.current["d"] || keysPressed.current["arrowright"] || keysPressed.current[right.toLowerCase()]) moveX += 1;
    } else {
      moveX = joystickDir.current.x;
      moveZ = joystickDir.current.y;
    }

    const inputDir = new THREE.Vector3(moveX, 0, moveZ);
    if (inputDir.lengthSq() > 0.001) {
      inputDir.normalize();
      playerFacing.current.copy(inputDir);
      isFacingLeft.current = playerFacing.current.x < 0;
    }

    if (attackTimer.current > 0) attackTimer.current -= dt;
    if (danceTimer.current > 0)  danceTimer.current  -= dt;
    if (playerInvincible.current > 0) playerInvincible.current -= dt;

    // ── Actions ──
    const atk1 = keysPressed.current["p"] || keysPressed.current[action1.toLowerCase()] || keysPressed.current[" "] || touchShootActive.current;
    const atk2 = keysPressed.current["o"] || keysPressed.current[action2.toLowerCase()];

    if (atk1 && attackTimer.current <= 0 && danceTimer.current <= 0) {
      attackTimer.current = 0.28;
      playerState.current = "attack";
      audio.playShoot();

      const attackPos = playerPos.current.clone().add(playerFacing.current.clone().multiplyScalar(1.3));
      const lookAngle = Math.atan2(-playerFacing.current.z, playerFacing.current.x) - Math.PI / 2;
      setSlashVisual({ active: true, position: [attackPos.x, 0.4, attackPos.z], angle: lookAngle, opacity: 1.0, color: godProps.slashColor });

      for (const e of enemies.current) {
        if (e.isDying) continue;
        const dist = playerPos.current.distanceTo(e.position);
        if (dist < (e.isBoss ? 4.5 : 3.5)) {
          const toEnemy = e.position.clone().sub(playerPos.current).normalize();
          if (toEnemy.dot(playerFacing.current) > 0.35) {
            const dmg = Math.floor((godProps.baseDamage + Math.random() * 10) * (1 + Math.floor(wave / 3) * 0.1));
            e.hp -= dmg;
            e.flashTimer = 0.18; // red flash

            addFloatingText(`-${dmg}`, godProps.slashColor, e.position);
            spawnParticles(e.position, godProps.slashColor, 8, 0.7);
            audio.playExplosion();

            e.hitCount++;

            if (e.hitCount === 1) {
              // First hit: knockback backward (away from player attack direction)
              const kbDir = playerFacing.current.clone().normalize();
              e.knockbackVel.copy(kbDir.multiplyScalar(18));
            } else if (e.hp <= 0 || e.hitCount >= 2) {
              // Second hit: die (white flash and vanish)
              e.isDying = true;
              e.dyingTimer = 0.6;
              e.whiteFlashTimer = 0.6;
              setScore(prev => prev + (e.isBoss ? 2000 : e.type === "normal" ? 150 : 100));
              setKills(prev => prev + 1);
              spawnParticles(e.position, e.isBoss ? "#fbbf24" : "#ffffff", e.isBoss ? 30 : 15, e.isBoss ? 2 : 1.2);
              // Chance to drop a potion
              if (Math.random() < (e.isBoss ? 1.0 : 0.25)) spawnItem(e.position);
            }
          }
        }
      }
    } else if (atk2 && danceTimer.current <= 0 && attackTimer.current <= 0 && localShieldCharge.current >= 100) {
      danceTimer.current = 0.5;
      playerState.current = "dance";
      localShieldCharge.current = 0;
      setShieldCharge(0);
      audio.playPowerUp();
      setBlastVisual({ active: true, position: [playerPos.current.x, 0.08, playerPos.current.z], radius: 0.2, opacity: 1.0, color: godProps.blastColor });
      addFloatingText("DIVINE BURST!", godProps.blastColor, playerPos.current);
      spawnParticles(playerPos.current, godProps.blastColor, 28, 1.8);
    }

    // ── Slash visual fade ──
    if (slashVisual.active) {
      setSlashVisual(p => {
        const o = p.opacity - dt * 7;
        return o <= 0 ? { ...p, active: false } : { ...p, opacity: o };
      });
    }

    // ── Blast visual expand + hit ──
    if (blastVisual.active) {
      setBlastVisual(p => {
        const r = p.radius + dt * 18;
        const o = p.opacity - dt * 2.2;
        for (const e of enemies.current) {
          if (e.isDying) continue;
          const d = playerPos.current.distanceTo(e.position);
          if (d < r && d > r - 2.5) {
            const dmg = Math.floor(80 + Math.random() * 40);
            e.hp -= dmg;
            e.flashTimer = 0.2;
            addFloatingText(`-${dmg} CRIT!`, godProps.blastColor, e.position);
            const dir = e.position.clone().sub(playerPos.current).normalize();
            e.knockbackVel.addScaledVector(dir, 30);
            spawnParticles(e.position, godProps.blastColor, 10, 1.2);
            audio.playExplosion();
            e.hitCount++;
            if (e.hitCount >= 2 || e.hp <= 0) {
              e.isDying = true; e.dyingTimer = 0.6; e.whiteFlashTimer = 0.6;
              setScore(prev => prev + (e.isBoss ? 2000 : 150));
              setKills(prev => prev + 1);
              spawnParticles(e.position, "#ffffff", 14, 1.2);
              if (Math.random() < 0.3) spawnItem(e.position);
            }
          }
        }
        if (r >= 9 || o <= 0) return { ...p, active: false };
        return { ...p, radius: r, opacity: o };
      });
    }

    // ── Shield recharge ──
    if (localShieldCharge.current < 100) {
      localShieldCharge.current = Math.min(100, localShieldCharge.current + dt * 20);
      setShieldCharge(Math.floor(localShieldCharge.current));
    }

    // ── Player state ──
    if (attackTimer.current > 0)     playerState.current = "attack";
    else if (danceTimer.current > 0) playerState.current = "dance";
    else if (inputDir.lengthSq() > 0.001) playerState.current = "walk";
    else playerState.current = "idle";

    // ── Player movement ──
    if (playerState.current === "walk") {
      playerVel.current.x += (inputDir.x * godProps.speed - playerVel.current.x) * 12 * dt;
      playerVel.current.z += (inputDir.z * godProps.speed - playerVel.current.z) * 12 * dt;
    } else {
      playerVel.current.x *= Math.pow(0.04, dt);
      playerVel.current.z *= Math.pow(0.04, dt);
    }
    playerPos.current.addScaledVector(playerVel.current, dt);
    playerPos.current.x = THREE.MathUtils.clamp(playerPos.current.x, -24, 24);
    playerPos.current.z = THREE.MathUtils.clamp(playerPos.current.z, -24, 24);

    if (playerMeshRef.current) {
      playerMeshRef.current.position.copy(playerPos.current);
      playerMeshRef.current.position.y = 1.0;
    }

    // ── Camera ──
    camera.position.x += (playerPos.current.x      - camera.position.x) * 6 * dt;
    camera.position.y += (playerPos.current.y + 12 - camera.position.y) * 6 * dt;
    camera.position.z += (playerPos.current.z + 14 - camera.position.z) * 6 * dt;
    camera.lookAt(playerPos.current.x, playerPos.current.y + 0.3, playerPos.current.z);

    // ── Player animation frames ──
    let rowIndex = 0, animSpeed = 6;
    if (playerState.current === "dance")  { rowIndex = 3; animSpeed = 12; }
    else if (playerState.current === "attack") { rowIndex = 2; animSpeed = 18; }
    else if (playerState.current === "walk")   { rowIndex = 1; animSpeed = 10; }
    frameTimer.current += dt;
    if (frameTimer.current >= 1 / animSpeed) { frameTimer.current = 0; animFrame.current = (animFrame.current + 1) % 4; }
    playerTexture.offset.set(animFrame.current * 0.25, (3 - rowIndex) * 0.25);

    // ── Spawn enemies ──
    spawnCooldown.current -= dt;
    const shouldSpawnBoss = wave % 3 === 0 && !bossSpawned.current && enemiesSpawnedThisWave.current >= Math.floor(totalEnemiesToSpawn.current * 0.6);
    if (shouldSpawnBoss) {
      bossSpawned.current = true;
      // Spawn boss from a random corner
      const corners = [
        new THREE.Vector3(20, 0, 20), new THREE.Vector3(-20, 0, 20),
        new THREE.Vector3(20, 0, -20), new THREE.Vector3(-20, 0, -20)
      ];
      const sp = corners[Math.floor(Math.random() * 4)];
      spawnParticles(sp, "#fbbf24", 20, 2);
      addFloatingText("⚠ BOSS!", "#fbbf24", sp);
      enemies.current.push({
        id: Math.random().toString(),
        position: sp.clone(), velocity: new THREE.Vector3(),
        hp: 300 + wave * 80, maxHp: 300 + wave * 80,
        speed: 2.2, size: 2.0,
        type: "normal", hitCount: 0,
        knockbackVel: new THREE.Vector3(),
        flashTimer: 0, whiteFlashTimer: 0, dyingTimer: 0, isDying: false,
        frameRow: 0, animFrame: 0, frameTimer: 0, facingLeft: false, isBoss: true, shootTimer: 2.0,
      });
    }

    if (spawnCooldown.current <= 0 && enemiesSpawnedThisWave.current < totalEnemiesToSpawn.current) {
      spawnCooldown.current = Math.max(0.7, 2.0 - wave * 0.1);
      const corners = [
        new THREE.Vector3(22, 0, 22), new THREE.Vector3(-22, 0, 22),
        new THREE.Vector3(22, 0, -22), new THREE.Vector3(-22, 0, -22)
      ];
      const sp = corners[Math.floor(Math.random() * 4)];
      spawnParticles(sp, "#8b5cf6", 10, 1.2);
      const hp = 60 + wave * 20;
      enemies.current.push({
        id: Math.random().toString(),
        position: sp.clone(), velocity: new THREE.Vector3(),
        hp, maxHp: hp,
        speed: 2.0 + Math.random() * 1.2 + wave * 0.1,
        size: 0.9,
        type: "normal", hitCount: 0,
        knockbackVel: new THREE.Vector3(),
        flashTimer: 0, whiteFlashTimer: 0, dyingTimer: 0, isDying: false,
        frameRow: 0, animFrame: 0, frameTimer: 0, facingLeft: false, isBoss: false, shootTimer: 0,
      });
      enemiesSpawnedThisWave.current++;
    }

    // ── Enemy updates ──
    for (let i = enemies.current.length - 1; i >= 0; i--) {
      const e = enemies.current[i];

      // Flash timers
      if (e.flashTimer > 0)      e.flashTimer -= dt;
      if (e.whiteFlashTimer > 0) e.whiteFlashTimer -= dt;

      // Death animation
      if (e.isDying) {
        e.dyingTimer -= dt;
        if (e.dyingTimer <= 0) {
          enemies.current.splice(i, 1);
          enemiesRemainingInWave.current = Math.max(0, enemiesRemainingInWave.current - 1);
        }
        continue;
      }

      // Apply knockback
      if (e.knockbackVel.lengthSq() > 0.01) {
        e.position.addScaledVector(e.knockbackVel, dt);
        e.knockbackVel.multiplyScalar(Math.pow(0.05, dt));
        // clamp
        e.position.x = THREE.MathUtils.clamp(e.position.x, -23, 23);
        e.position.z = THREE.MathUtils.clamp(e.position.z, -23, 23);
      }

      // Move toward player
      const dir = playerPos.current.clone().sub(e.position).normalize();
      if (e.knockbackVel.lengthSq() < 0.5) {
        e.position.addScaledVector(dir, e.speed * dt);
      }
      e.position.y = e.isBoss ? 1.5 : 0.7;

      // Facing direction
      e.facingLeft = dir.x < 0;

      // Animate enemy sprite (row0=stand when close, row1=walk)
      const distToPlayer = e.position.distanceTo(playerPos.current);
      e.frameRow = distToPlayer > 2.5 ? 1 : 0; // walk row when far, stand when close
      const eAnimSpeed = e.frameRow === 1 ? 8 : 4;
      e.frameTimer += dt;
      if (e.frameTimer >= 1 / eAnimSpeed) {
        e.frameTimer = 0;
        e.animFrame = (e.animFrame + 1) % 4;
      }

      // Boss projectile shooting
      if (e.isBoss) {
        // Boss shoots every 2s
        e.shootTimer -= dt;
        if (e.shootTimer <= 0) {
          e.shootTimer = 2.0;
          const projDir = playerPos.current.clone().sub(e.position).normalize();
          projectiles.current.push({
            id: Math.random().toString(),
            position: e.position.clone().add(new THREE.Vector3(0, 0.5, 0)),
            velocity: projDir.multiplyScalar(8),
            size: 0.35, damage: 1, color: "#fbbf24",
          });
          audio.playShoot();
        }
      }

      // Melee damage to player
      if (distToPlayer < (e.isBoss ? 2.5 : 1.2) && playerInvincible.current <= 0) {
        playerInvincible.current = 1.2; // 1.2s invincibility
        setPlayerHearts(prev => {
          const next = prev - 1;
          if (next <= 0) { setIsGameOver(true); setIsPlaying(false); audio.playGameOver(); }
          return Math.max(0, next);
        });
        addFloatingText("💔", "#f87171", playerPos.current);
        spawnParticles(playerPos.current, "#ef4444", 6, 0.6);
        audio.playExplosion();
        // Push enemy back
        const push = e.position.clone().sub(playerPos.current).normalize();
        e.knockbackVel.addScaledVector(push, 8);
      }
    }

    // ── Projectile updates ──
    for (let i = projectiles.current.length - 1; i >= 0; i--) {
      const p = projectiles.current[i];
      p.position.addScaledVector(p.velocity, dt);
      if (p.position.length() > 36) { projectiles.current.splice(i, 1); continue; }
      if (p.position.distanceTo(playerPos.current) < p.size + 0.7 && playerInvincible.current <= 0) {
        projectiles.current.splice(i, 1);
        playerInvincible.current = 0.8;
        setPlayerHearts(prev => {
          const next = prev - 1;
          if (next <= 0) { setIsGameOver(true); setIsPlaying(false); audio.playGameOver(); }
          return Math.max(0, next);
        });
        addFloatingText("💔", "#f87171", playerPos.current);
        spawnParticles(playerPos.current, "#fbbf24", 8, 0.9);
        audio.playExplosion();
      }
    }

    // ── Item pickup ──
    for (let i = items.current.length - 1; i >= 0; i--) {
      const item = items.current[i];
      const d2d = Math.hypot(playerPos.current.x - item.position.x, playerPos.current.z - item.position.z);
      if (d2d < 1.4) {
        items.current.splice(i, 1);
        setPlayerHearts(prev => Math.min(5, prev + 1));
        addFloatingText("💊 +1 LIFE", "#4ade80", playerPos.current);
        spawnParticles(playerPos.current, "#4ade80", 10, 0.8);
        audio.playPowerUp();
      }
    }

    // ── Particles ──
    for (let i = particles.current.length - 1; i >= 0; i--) {
      const pt = particles.current[i];
      pt.position.addScaledVector(pt.velocity, dt);
      pt.velocity.y -= 9.8 * dt;
      pt.life -= dt;
      if (pt.life <= 0) particles.current.splice(i, 1);
    }

    // ── Wave transition ──
    if (enemiesRemainingInWave.current <= 0 && enemiesSpawnedThisWave.current >= totalEnemiesToSpawn.current && enemies.current.length === 0) {
      if (nextWaveDelayTimer.current === 0) {
        nextWaveDelayTimer.current = 3.5;
        setScore(prev => prev + wave * 800);
        audio.playPowerUp();
        addFloatingText(`WAVE ${wave} CLEAR! +${wave * 800}`, "#fbbf24", playerPos.current);
      } else {
        nextWaveDelayTimer.current -= dt;
        if (nextWaveDelayTimer.current <= 0) setWave(prev => prev + 1);
      }
    }

    // Force re-render for entity animations
    setRenderTick(t => t + 1);
  });

  // ── Lighting ──
  return (
    <>
      {/* Ambient + directional lights */}
      <ambientLight intensity={0.45} color="#1a0a2e" />
      <directionalLight position={[5, 12, 5]} intensity={1.2} color="#ffe8c0" castShadow
        shadow-mapSize={[1024, 1024]} shadow-camera-far={50} shadow-camera-left={-25} shadow-camera-right={25}
        shadow-camera-top={25} shadow-camera-bottom={-25} />
      <pointLight position={[0, 8, 0]} intensity={0.6} color="#ff6030" distance={30} />
      {/* God color accent light near player */}
      <pointLight position={[playerPos.current.x, 3, playerPos.current.z]} intensity={1.2} color={godProps.glow} distance={8} />

      {/* ── Ground plane 50×50 with texture ── */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow position={[0, -0.01, 0]}>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial map={groundTexture} roughness={0.75} metalness={0.08} />
      </mesh>

      {/* ── Arena border walls (invisible but solid visual markers - pillars) ── */}
      {[[-20,-20],[-20,20],[20,-20],[20,20],[0,-24],[0,24],[-24,0],[24,0]].map(([px,pz],i) => (
        <mesh key={i} position={[px, 2, pz]} castShadow receiveShadow>
          <boxGeometry args={[1.4, 4, 1.4]} />
          <meshStandardMaterial color="#110d1a" roughness={0.95} emissive="#1a0a2e" emissiveIntensity={0.3} />
        </mesh>
      ))}

      {/* ── Norse Spawn Portals ── */}
      {[[22,22],[-22,22],[22,-22],[-22,-22]].map(([px,pz],i) => (
        <group key={i} position={[px, 0.35, pz]}>
          <mesh rotation={[Math.PI/2, 0, i * 0.4]}>
            <torusGeometry args={[1.5, 0.1, 10, 48]} />
            <meshBasicMaterial color="#7c3aed" />
          </mesh>
          <mesh rotation={[-Math.PI/2, 0, 0]}>
            <circleGeometry args={[1.4, 32]} />
            <meshBasicMaterial color="#4c1d95" transparent opacity={0.3} />
          </mesh>
        </group>
      ))}

      {/* ── Player Billboard ── */}
      <Billboard ref={playerMeshRef as any} position={[0, 1.0, 0]}>
        <mesh castShadow>
          <planeGeometry args={[2.4, 2.4]} />
          <meshBasicMaterial map={playerTexture} transparent alphaTest={0.4} side={THREE.DoubleSide} />
        </mesh>
        {/* Glow ring under player */}
        <mesh rotation={[-Math.PI/2, 0, 0]} position={[0, -1.15, 0]}>
          <ringGeometry args={[0.48, 0.62, 32]} />
          <meshBasicMaterial color={godProps.glow} transparent opacity={playerInvincible.current > 0 ? 0.95 : 0.65} />
        </mesh>
      </Billboard>

      {/* ── Enemies ── */}
      {enemies.current.map((enemy) => {
        const hpPct = Math.max(0, enemy.hp / enemy.maxHp);
        const isFlashRed   = enemy.flashTimer > 0;
        const isFlashWhite = enemy.whiteFlashTimer > 0;
        const dyingScale   = enemy.isDying ? Math.max(0.01, enemy.dyingTimer / 0.6) : 1;
        const scale        = enemy.isBoss ? 3.2 : 1.8;

        // UV for enemy sprite sheet: 4 frames wide, 2 rows
        // row 0 = stand (top half), row 1 = walk (bottom half)
        // facing: sprite faces left by default; flip scaleX if moving right
        const frameOffsetX = enemy.animFrame * 0.25;
        const frameOffsetY = enemy.frameRow === 0 ? 0.5 : 0.0; // row0=stand top, row1=walk bottom

        return (
          <Billboard key={enemy.id} position={[enemy.position.x, enemy.position.y, enemy.position.z]}>
            <group scale={[dyingScale, dyingScale, dyingScale]}>
              {/* Enemy sprite */}
              <mesh castShadow scale={[enemy.facingLeft ? 1 : -1, 1, 1]}>
                <planeGeometry args={[scale, scale]} />
                <meshBasicMaterial
                  map={enemy.isBoss
                    ? (() => { return bossTexture; })()
                    : (() => {
                        // Create an offset clone for this enemy's frame
                        const t = enemyTexture.clone();
                        t.offset.set(frameOffsetX, frameOffsetY);
                        t.repeat.set(0.25, 0.5);
                        t.needsUpdate = true;
                        return t;
                      })()}
                  transparent alphaTest={0.38}
                  color={isFlashWhite ? "#ffffff" : isFlashRed ? "#ff4444" : "#ffffff"}
                  side={THREE.DoubleSide}
                />
              </mesh>

              {/* HP bar (only for non-dying) */}
              {!enemy.isDying && (
                <group position={[0, scale * 0.62, 0]}>
                  <mesh>
                    <planeGeometry args={[enemy.isBoss ? 2.0 : 1.2, 0.12]} />
                    <meshBasicMaterial color="#450a0a" />
                  </mesh>
                  <mesh position={[(-0.5 + hpPct * 0.5) * (enemy.isBoss ? 2.0 : 1.2), 0, 0.01]}>
                    <planeGeometry args={[hpPct * (enemy.isBoss ? 2.0 : 1.2), 0.12]} />
                    <meshBasicMaterial color={enemy.isBoss ? "#fbbf24" : "#ef4444"} />
                  </mesh>
                  {enemy.isBoss && (
                    <Html center position={[0, 0.15, 0]} distanceFactor={10}>
                      <div style={{ color: "#fbbf24", fontSize: "8px", fontFamily: "monospace", fontWeight: "bold", whiteSpace: "nowrap", textShadow: "0 0 4px rgba(0,0,0,1)" }}>
                        ☠ BOSS
                      </div>
                    </Html>
                  )}
                </group>
              )}
            </group>
          </Billboard>
        );
      })}

      {/* ── Items (potions) ── */}
      {items.current.map((item) => (
        <Billboard key={item.id} position={[item.position.x, item.position.y, item.position.z]}>
          <mesh>
            <planeGeometry args={[0.9, 0.9]} />
            <meshBasicMaterial map={itemTexture} transparent alphaTest={0.35} side={THREE.DoubleSide} />
          </mesh>
          {/* Glow under potion */}
          <mesh rotation={[-Math.PI/2, 0, 0]} position={[0, -0.5, 0]}>
            <ringGeometry args={[0.2, 0.35, 16]} />
            <meshBasicMaterial color="#4ade80" transparent opacity={0.7} />
          </mesh>
        </Billboard>
      ))}

      {/* ── Slash arc ── */}
      {slashVisual.active && (
        <mesh position={slashVisual.position} rotation={[Math.PI/2, 0, slashVisual.angle]}>
          <ringGeometry args={[0.4, 2.2, 32, 1, 0, Math.PI]} />
          <meshBasicMaterial color={slashVisual.color} transparent opacity={slashVisual.opacity} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* ── Blast ring ── */}
      {blastVisual.active && (
        <mesh position={blastVisual.position} rotation={[Math.PI/2, 0, 0]}>
          <ringGeometry args={[Math.max(0, blastVisual.radius - 0.5), blastVisual.radius, 48]} />
          <meshBasicMaterial color={blastVisual.color} transparent opacity={blastVisual.opacity} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* ── Projectiles ── */}
      {projectiles.current.map(p => (
        <mesh key={p.id} position={p.position}>
          <sphereGeometry args={[p.size, 8, 8]} />
          <meshBasicMaterial color={p.color} />
        </mesh>
      ))}

      {/* ── Particles ── */}
      {particles.current.map(pt => (
        <mesh key={pt.id} position={pt.position}>
          <boxGeometry args={[pt.size, pt.size, pt.size]} />
          <meshBasicMaterial color={pt.color} transparent opacity={pt.life / pt.maxLife} />
        </mesh>
      ))}

      {/* ── Floating texts ── */}
      {floatingTexts.map(ft => (
        <Html key={ft.id} position={ft.position} center distanceFactor={14}>
          <div style={{ color: ft.color }} className="font-mono text-xs font-black tracking-widest drop-shadow-[0_2px_5px_rgba(0,0,0,1)] select-none pointer-events-none animate-float-fade whitespace-nowrap">
            {ft.text}
          </div>
        </Html>
      ))}
    </>
  );
}
