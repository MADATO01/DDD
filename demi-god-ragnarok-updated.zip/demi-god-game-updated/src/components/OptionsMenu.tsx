import React, { useState, useEffect } from "react";
import { GameSettings, ControlMode, MovementKeys, KeyBindings } from "../types";
import { audio } from "../utils/audio";
import { 
  Keyboard, 
  Tv, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  AlertTriangle, 
  ChevronLeft, 
  Check, 
  RefreshCw,
  Joystick
} from "lucide-react";

interface OptionsMenuProps {
  settings: GameSettings;
  onSave: (settings: GameSettings) => void;
  onBack: () => void;
}

const DEFAULT_BINDINGS_WASD: KeyBindings = {
  up: "w",
  down: "s",
  left: "a",
  right: "d",
  action1: " ", // Space
  action2: "shift",
};

const DEFAULT_BINDINGS_ARROWS: KeyBindings = {
  up: "arrowup",
  down: "arrowdown",
  left: "arrowleft",
  right: "arrowright",
  action1: "z",
  action2: "x",
};

export default function OptionsMenu({ settings, onSave, onBack }: OptionsMenuProps) {
  const [currentSettings, setCurrentSettings] = useState<GameSettings>({ ...settings });
  const [rebindingField, setRebindingField] = useState<keyof KeyBindings | null>(null);

  useEffect(() => {
    // Sync current BGM volume and status
    audio.setVolume(currentSettings.volume);
    audio.setSoundEnabled(currentSettings.soundEnabled);
  }, [currentSettings.volume, currentSettings.soundEnabled]);

  const handleModeChange = (mode: ControlMode) => {
    audio.playClick();
    setCurrentSettings(prev => ({
      ...prev,
      controlMode: mode,
    }));
  };

  const handleMovementKeysChange = (scheme: MovementKeys) => {
    audio.playClick();
    const defaults = scheme === MovementKeys.WASD ? DEFAULT_BINDINGS_WASD : DEFAULT_BINDINGS_ARROWS;
    setCurrentSettings(prev => ({
      ...prev,
      movementKeys: scheme,
      bindings: { ...defaults },
    }));
  };

  const startRebinding = (field: keyof KeyBindings) => {
    audio.playClick();
    setRebindingField(field);
  };

  useEffect(() => {
    if (!rebindingField) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      e.preventDefault();
      const key = e.key.toLowerCase();
      
      setCurrentSettings(prev => ({
        ...prev,
        bindings: {
          ...prev.bindings,
          [rebindingField]: key,
        }
      }));
      setRebindingField(null);
      audio.playPowerUp();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [rebindingField]);

  const handleToggleSound = () => {
    audio.playClick();
    setCurrentSettings(prev => ({
      ...prev,
      soundEnabled: !prev.soundEnabled,
    }));
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setCurrentSettings(prev => ({
      ...prev,
      volume: vol,
    }));
  };

  const handleToggleParticles = () => {
    audio.playClick();
    setCurrentSettings(prev => ({
      ...prev,
      particlesEnabled: !prev.particlesEnabled,
    }));
  };

  const handleToggleScreenShake = () => {
    audio.playClick();
    setCurrentSettings(prev => ({
      ...prev,
      screenShakeEnabled: !prev.screenShakeEnabled,
    }));
  };

  const handleReset = () => {
    audio.playPowerUp();
    const resetSettings: GameSettings = {
      controlMode: ControlMode.Keyboard,
      movementKeys: MovementKeys.WASD,
      bindings: { ...DEFAULT_BINDINGS_WASD },
      soundEnabled: true,
      volume: 0.5,
      particlesEnabled: true,
      screenShakeEnabled: true,
    };
    setCurrentSettings(resetSettings);
  };

  const handleSave = () => {
    audio.playPowerUp();
    onSave(currentSettings);
  };

  const formatKeyName = (key: string) => {
    if (key === " ") return "SPACE";
    return key.toUpperCase();
  };

  return (
    <div id="options-menu-container" className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-6 relative overflow-hidden select-none">
      
      {/* Cool Grid Matrix Background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.03),rgba(0,255,0,0.01),rgba(0,0,255,0.03))] bg-[size:100%_4px,6px_100%] pointer-events-none z-0" />
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(220,38,38,0.1)_0%,transparent_70%)] pointer-events-none z-0" />
      
      {/* Floating Ambient Particles inside menu */}
      <div className="absolute -top-12 -left-12 w-64 h-64 bg-red-900/10 blur-3xl rounded-full animate-pulse pointer-events-none" />
      <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-red-900/10 blur-3xl rounded-full animate-pulse pointer-events-none" />

      {/* Main Container Card */}
      <div id="options-card" className="w-full max-w-2xl bg-zinc-950 border-2 border-red-600/80 rounded-lg p-6 md:p-8 shadow-[0_0_25px_rgba(220,38,38,0.25)] relative z-10 animate-fade-in backdrop-blur-md">
        
        {/* Futuristic corners */}
        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-red-500 -mt-[2px] -ml-[2px]" />
        <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-red-500 -mt-[2px] -mr-[2px]" />
        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-red-500 -mb-[2px] -ml-[2px]" />
        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-red-500 -mb-[2px] -mr-[2px]" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-red-900/40 pb-4 mb-6">
          <button 
            id="back-button"
            onClick={onBack}
            className="flex items-center gap-1 text-zinc-400 hover:text-red-500 transition-colors py-1 px-3 border border-zinc-800 hover:border-red-600/50 rounded bg-zinc-900 text-xs tracking-wider font-mono"
          >
            <ChevronLeft size={16} /> Back
          </button>
          <h2 className="text-xl md:text-2xl font-bold uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white via-red-200 to-red-500 flex items-center gap-2 font-mono">
            <Keyboard className="text-red-500 animate-pulse" size={24} /> OPTIONS MENU
          </h2>
          <button 
            id="reset-button"
            onClick={handleReset}
            className="flex items-center gap-1 text-zinc-400 hover:text-yellow-500 transition-colors py-1 px-3 border border-zinc-800 hover:border-yellow-600/50 rounded bg-zinc-900 text-xs tracking-wider font-mono"
            title="Reset to default settings"
          >
            <RefreshCw size={14} /> Reset
          </button>
        </div>

        {/* Content Tabs/Grid */}
        <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-red-600 scrollbar-track-zinc-900">
          
          {/* Section 1: Control Mode */}
          <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-md">
            <h3 className="text-sm font-semibold tracking-wider text-red-500 mb-3 flex items-center gap-1.5 font-mono">
              <Joystick size={16} /> CONTROL INTERFACE
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                id="keyboard-mode-btn"
                onClick={() => handleModeChange(ControlMode.Keyboard)}
                className={`flex flex-col items-center justify-center p-3 rounded border transition-all ${
                  currentSettings.controlMode === ControlMode.Keyboard
                    ? "border-red-500 bg-red-950/20 text-white shadow-[0_0_10px_rgba(220,38,38,0.15)]"
                    : "border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:border-zinc-700 hover:text-white"
                }`}
              >
                <Keyboard size={24} className="mb-1" />
                <span className="text-xs font-bold uppercase tracking-wider font-mono">Keyboard</span>
                <span className="text-[10px] text-zinc-500 mt-1 font-mono">WASD / Arrow Keys</span>
              </button>

              <button
                id="touch-mode-btn"
                onClick={() => handleModeChange(ControlMode.Touch)}
                className={`flex flex-col items-center justify-center p-3 rounded border transition-all ${
                  currentSettings.controlMode === ControlMode.Touch
                    ? "border-red-500 bg-red-950/20 text-white shadow-[0_0_10px_rgba(220,38,38,0.15)]"
                    : "border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:border-zinc-700 hover:text-white"
                }`}
              >
                <Tv size={24} className="mb-1" />
                <span className="text-xs font-bold uppercase tracking-wider font-mono">Touch Screen</span>
                <span className="text-[10px] text-zinc-500 mt-1 font-mono">Virtual Joystick & Buttons</span>
              </button>
            </div>
          </div>

          {/* Section 2: Keyboard Layout & Rebinding */}
          {currentSettings.controlMode === ControlMode.Keyboard && (
            <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-md animate-fade-in">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-semibold tracking-wider text-red-500 flex items-center gap-1.5 font-mono">
                  <Keyboard size={16} /> KEYBOARD MAPPINGS
                </h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleMovementKeysChange(MovementKeys.WASD)}
                    className={`px-2 py-1 text-[10px] font-bold border rounded uppercase tracking-wider transition-colors font-mono ${
                      currentSettings.movementKeys === MovementKeys.WASD
                        ? "border-red-500 bg-red-950/30 text-white"
                        : "border-zinc-800 bg-zinc-900 text-zinc-500 hover:text-white"
                    }`}
                  >
                    WASD Scheme
                  </button>
                  <button
                    onClick={() => handleMovementKeysChange(MovementKeys.Arrows)}
                    className={`px-2 py-1 text-[10px] font-bold border rounded uppercase tracking-wider transition-colors font-mono ${
                      currentSettings.movementKeys === MovementKeys.Arrows
                        ? "border-red-500 bg-red-950/30 text-white"
                        : "border-zinc-800 bg-zinc-900 text-zinc-500 hover:text-white"
                    }`}
                  >
                    ARROWS Scheme
                  </button>
                </div>
              </div>

              {/* Custom key mapper table */}
              <div className="grid grid-cols-2 gap-3 text-xs mt-2">
                {[
                  { label: "Glide Up", key: "up" },
                  { label: "Glide Down", key: "down" },
                  { label: "Glide Left", key: "left" },
                  { label: "Glide Right", key: "right" },
                  { label: "Cast Spell / Attack", key: "action1" },
                  { label: "Shield Aegis", key: "action2" },
                ].map(({ label, key }) => {
                  const bindingKey = key as keyof KeyBindings;
                  const isRebinding = rebindingField === bindingKey;
                  return (
                    <div key={key} className="flex items-center justify-between bg-zinc-950 p-2.5 rounded border border-zinc-800/80 hover:border-zinc-700/80 transition-colors font-mono">
                      <span className="text-zinc-300 font-medium">{label}</span>
                      <button
                        onClick={() => startRebinding(bindingKey)}
                        className={`px-3 py-1 font-mono rounded font-bold border min-w-[70px] text-center transition-all ${
                          isRebinding
                            ? "bg-red-600 border-red-500 text-white animate-pulse shadow-[0_0_12px_rgba(239,68,68,0.4)]"
                            : "bg-zinc-900 border-zinc-800 hover:border-red-600 text-red-400 hover:text-white"
                        }`}
                      >
                        {isRebinding ? "???" : formatKeyName(currentSettings.bindings[bindingKey])}
                      </button>
                    </div>
                  );
                })}
              </div>
              <p className="text-[10px] text-zinc-500 mt-3 flex items-center gap-1.5 bg-black/40 p-2 rounded border border-zinc-800/30 font-mono">
                <AlertTriangle size={12} className="text-yellow-500 shrink-0" />
                Click any control field button and press a key on your keyboard to assign custom bindings.
              </p>
            </div>
          )}

          {/* Section 3: Audio (Web Synthesizer) */}
          <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-md">
            <h3 className="text-sm font-semibold tracking-wider text-red-500 mb-3 flex items-center gap-1.5 font-mono">
              <Volume2 size={16} /> SOUND & MUSIC SYNTHESIZER
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between font-mono">
                <span className="text-xs text-zinc-300">Master Volume Mute</span>
                <button
                  id="sound-toggle-btn"
                  onClick={handleToggleSound}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded border text-xs font-bold uppercase transition-all ${
                    currentSettings.soundEnabled
                      ? "border-red-500 bg-red-950/20 text-red-400 hover:bg-red-950/30"
                      : "border-zinc-800 bg-zinc-950/40 text-zinc-400 hover:bg-zinc-900/40"
                  }`}
                >
                  {currentSettings.soundEnabled ? (
                    <>
                      <Volume2 size={14} /> Enabled
                    </>
                  ) : (
                    <>
                      <VolumeX size={14} /> Muted
                    </>
                  )}
                </button>
              </div>

              {currentSettings.soundEnabled && (
                <div className="flex items-center gap-4 bg-zinc-950/60 p-3 rounded border border-zinc-900 font-mono">
                  <span className="text-xs text-zinc-400 min-w-[70px]">Volume</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={currentSettings.volume}
                    onChange={handleVolumeChange}
                    className="w-full accent-red-600 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs font-mono text-zinc-300 min-w-[30px] text-right">
                    {Math.round(currentSettings.volume * 100)}%
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Section 4: Visuals & FX */}
          <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-md">
            <h3 className="text-sm font-semibold tracking-wider text-red-500 mb-3 flex items-center gap-1.5 font-mono">
              <Sparkles size={16} /> GRAPHICS & PARTICLE SHADERS
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <button
                onClick={handleToggleParticles}
                className={`flex items-center justify-between p-3 rounded border transition-all ${
                  currentSettings.particlesEnabled
                    ? "border-red-500/50 bg-red-950/10 text-white"
                    : "border-zinc-800 bg-zinc-950/40 text-zinc-500"
                }`}
              >
                <span>Starlight Glow Shaders</span>
                <span className={`w-2.5 h-2.5 rounded-full ${currentSettings.particlesEnabled ? "bg-red-500 animate-pulse shadow-[0_0_8px_rgba(239,68,68,1)]" : "bg-zinc-800"}`} />
              </button>

              <button
                onClick={handleToggleScreenShake}
                className={`flex items-center justify-between p-3 rounded border transition-all ${
                  currentSettings.screenShakeEnabled
                    ? "border-red-500/50 bg-red-950/10 text-white"
                    : "border-zinc-800 bg-zinc-950/40 text-zinc-500"
                }`}
              >
                <span>Impact Screen Shake</span>
                <span className={`w-2.5 h-2.5 rounded-full ${currentSettings.screenShakeEnabled ? "bg-red-500 animate-pulse shadow-[0_0_8px_rgba(239,68,68,1)]" : "bg-zinc-800"}`} />
              </button>
            </div>
          </div>

        </div>

        {/* Footer actions */}
        <div className="mt-8 pt-4 border-t border-red-900/40 flex justify-end gap-3 font-mono">
          <button
            onClick={onBack}
            className="px-5 py-2 rounded bg-zinc-950 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900 text-zinc-300 font-bold tracking-wider text-xs uppercase transition-all"
          >
            Cancel
          </button>
          <button
            id="save-settings-btn"
            onClick={handleSave}
            className="px-6 py-2 rounded bg-red-600 hover:bg-red-500 text-white font-bold tracking-widest text-xs uppercase transition-all shadow-[0_0_15px_rgba(220,38,38,0.4)] hover:shadow-[0_0_20px_rgba(220,38,38,0.6)] flex items-center gap-1.5"
          >
            <Check size={14} /> Save Configuration
          </button>
        </div>

      </div>
    </div>
  );
}
