import React, { useState, useEffect } from "react";
import { ScoreRecord } from "../types";
import { audio } from "../utils/audio";
import { Award, Trophy, Trash2, Calendar, ShieldAlert, ChevronLeft } from "lucide-react";

interface LeaderboardProps {
  onBack: () => void;
}

const DEFAULT_SCORES: ScoreRecord[] = [
  { id: "1", name: "THOR_CHAMP", score: 18450, wave: 15, date: "2026-06-25" },
  { id: "2", name: "ARES_WARLORD", score: 14900, wave: 11, date: "2026-06-26" },
  { id: "3", name: "VALKYRIE_LGT", score: 12520, wave: 9, date: "2026-06-27" },
  { id: "4", name: "SHADOW_LOKI", score: 9310, wave: 7, date: "2026-06-28" },
  { id: "5", name: "ODIN_SENTINL", score: 6500, wave: 4, date: "2026-06-28" },
];

export default function Leaderboard({ onBack }: LeaderboardProps) {
  const [scores, setScores] = useState<ScoreRecord[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("crimson_arcade_high_scores");
    if (saved) {
      try {
        setScores(JSON.parse(saved));
      } catch (e) {
        setScores(DEFAULT_SCORES);
      }
    } else {
      localStorage.setItem("crimson_arcade_high_scores", JSON.stringify(DEFAULT_SCORES));
      setScores(DEFAULT_SCORES);
    }
  }, []);

  const handleClearScores = () => {
    if (window.confirm("Are you sure you want to clear all high score records from Valhalla?")) {
      audio.playExplosion();
      localStorage.removeItem("crimson_arcade_high_scores");
      setScores([]);
    }
  };

  return (
    <div id="leaderboard-container" className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-6 relative overflow-hidden select-none">
      
      {/* Background aesthetic lines */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.02),rgba(0,0,0,0),rgba(0,0,255,0.02))] bg-[size:100%_4px,6px_100%] pointer-events-none z-0" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-red-950/10 rounded-full blur-[100px] pointer-events-none z-0" />

      {/* Leaderboard Card */}
      <div id="leaderboard-card" className="w-full max-w-lg bg-zinc-950 border-2 border-red-600 rounded-lg p-6 md:p-8 shadow-[0_0_25px_rgba(220,38,38,0.25)] relative z-10 animate-fade-in backdrop-blur-md">
        
        {/* Tech Corner Graphics */}
        <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-red-500 -mt-[1px] -ml-[1px]" />
        <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-red-500 -mt-[1px] -mr-[1px]" />
        <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-red-500 -mb-[1px] -ml-[1px]" />
        <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-red-500 -mb-[1px] -mr-[1px]" />

        {/* Title */}
        <div className="flex items-center justify-between border-b border-red-900/40 pb-4 mb-6">
          <button 
            id="leaderboard-back-btn"
            onClick={() => {
              audio.playClick();
              onBack();
            }}
            className="flex items-center gap-1 text-zinc-400 hover:text-red-500 transition-colors py-1 px-3 border border-zinc-800 hover:border-red-600/50 rounded bg-zinc-900 text-xs tracking-wider font-mono"
          >
            <ChevronLeft size={16} /> Back
          </button>
          
          <h2 className="text-lg md:text-xl font-bold uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white via-red-200 to-red-500 flex items-center gap-2 font-mono">
            <Trophy className="text-yellow-500 animate-bounce" size={22} /> VALHALLA ARENA
          </h2>

          <button 
            onClick={handleClearScores}
            disabled={scores.length === 0}
            className={`p-1.5 rounded border text-zinc-400 hover:text-red-500 transition-colors bg-zinc-900 text-xs ${scores.length === 0 ? "opacity-30 cursor-not-allowed border-zinc-900" : "border-zinc-800 hover:border-red-600/50"}`}
            title="Clear high scores"
          >
            <Trash2 size={14} />
          </button>
        </div>

        {/* High Scores List */}
        <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-red-600 scrollbar-track-zinc-900">
          {scores.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-zinc-500 text-sm border border-dashed border-zinc-800 rounded font-mono">
              <ShieldAlert size={28} className="mb-2 text-red-500" />
              No divine efforts recorded in the high score database.
            </div>
          ) : (
            scores
              .sort((a, b) => b.score - a.score)
              .map((record, index) => {
                const rank = index + 1;
                let rankColor = "text-zinc-400 border-zinc-800";
                let rankIcon = null;

                if (rank === 1) {
                  rankColor = "text-yellow-400 border-yellow-500/50 bg-yellow-500/10";
                  rankIcon = <Trophy size={14} className="text-yellow-400 shrink-0" />;
                } else if (rank === 2) {
                  rankColor = "text-zinc-300 border-zinc-400/50 bg-zinc-400/10";
                } else if (rank === 3) {
                  rankColor = "text-amber-600 border-amber-700/50 bg-amber-700/10";
                }

                return (
                  <div 
                    key={record.id} 
                    className={`flex items-center justify-between p-3 rounded border bg-zinc-900/50 hover:bg-zinc-900 transition-all duration-300 hover:-translate-y-[1px] ${
                      rank <= 3 ? "border-red-600/40" : "border-zinc-800/80"
                    }`}
                  >
                    {/* Rank & Name */}
                    <div className="flex items-center gap-3">
                      <div className={`w-6 h-6 flex items-center justify-center text-xs font-bold rounded border ${rankColor}`}>
                        {rankIcon || rank}
                      </div>
                      <div className="flex flex-col font-mono">
                        <span className="text-sm tracking-wider font-semibold text-white uppercase">
                          {record.name}
                        </span>
                        <span className="text-[10px] text-zinc-500 flex items-center gap-1">
                          <Calendar size={10} /> {record.date}
                        </span>
                      </div>
                    </div>

                    {/* Wave & Score */}
                    <div className="flex items-center gap-4 text-right font-mono">
                      <div className="flex flex-col">
                        <span className="text-[10px] uppercase text-zinc-500 font-bold tracking-wider">
                          WAVE
                        </span>
                        <span className="text-xs text-red-400 font-bold">
                          {record.wave}
                        </span>
                      </div>
                      <div className="flex flex-col bg-black/40 px-3 py-1.5 rounded border border-zinc-800/60 min-w-[90px] items-end justify-center">
                        <span className="text-[9px] uppercase text-zinc-500 font-semibold tracking-wider">
                          SCORE
                        </span>
                        <span className="text-sm text-white font-bold leading-none mt-0.5">
                          {record.score.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
          )}
        </div>

        {/* Back Button Footer */}
        <div className="mt-6 pt-4 border-t border-red-900/40 flex justify-center font-mono">
          <button
            onClick={() => {
              audio.playClick();
              onBack();
            }}
            className="px-8 py-2.5 rounded bg-red-600 hover:bg-red-500 text-white font-bold tracking-widest text-xs uppercase transition-all shadow-[0_0_15px_rgba(220,38,38,0.3)] hover:shadow-[0_0_20px_rgba(220,38,38,0.5)] flex items-center gap-1.5"
          >
            <Award size={14} /> Return to Main Menu
          </button>
        </div>

      </div>
    </div>
  );
}
