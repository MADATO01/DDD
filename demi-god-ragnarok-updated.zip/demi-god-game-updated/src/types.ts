export enum ControlMode {
  Keyboard = "KEYBOARD",
  Touch = "TOUCH",
}

export enum MovementKeys {
  WASD = "WASD",
  Arrows = "ARROWS",
}

export enum GodAffinity {
  Thor = "THOR_THUNDER",
  Ares = "ARES_WAR",
  Freya = "FREYA_LIGHT",
  Loki = "LOKI_SHADOW",
}

export interface KeyBindings {
  up: string;
  down: string;
  left: string;
  right: string;
  action1: string; // Shoot/Attack
  action2: string; // Dash/Shield
}

export interface GameSettings {
  controlMode: ControlMode;
  movementKeys: MovementKeys;
  bindings: KeyBindings;
  soundEnabled: boolean;
  volume: number;
  particlesEnabled: boolean;
  screenShakeEnabled: boolean;
}

export interface ScoreRecord {
  id: string;
  name: string;
  score: number;
  date: string;
  wave: number;
}

